// AI Student Life Assistant — Express API + SQLite
// ใช้ Node.js 20+; รหัสผ่านเก็บเป็น bcrypt hash และ session ใช้ cookie แบบ HttpOnly
const path = require('path');
const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const bcrypt = require('bcryptjs');
const Database = require('better-sqlite3');
const cookieParser = require('cookie-parser');
const jwt = require('jsonwebtoken');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const NODE_ENV = process.env.NODE_ENV || 'development';
const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET || JWT_SECRET.length < 32) {
  console.error('ERROR: ตั้งค่า JWT_SECRET เป็น secret สุ่มยาวอย่างน้อย 32 ตัวอักษรใน environment ก่อนเริ่มเซิร์ฟเวอร์');
  process.exit(1);
}

const dataDir = process.env.DATA_DIR || path.join(__dirname, 'data');
require('fs').mkdirSync(dataDir, {recursive:true});
const db = new Database(path.join(dataDir, 'student-life.sqlite'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.exec(`
 CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  student_id TEXT NOT NULL UNIQUE,
  first_name TEXT NOT NULL,
  last_name TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
 );
 CREATE TABLE IF NOT EXISTS tasks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  name TEXT NOT NULL,
  due_date TEXT NOT NULL,
  hours REAL NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
 );
 CREATE INDEX IF NOT EXISTS idx_tasks_user_due ON tasks(user_id, due_date);
`);

app.disable('x-powered-by');
app.use(helmet({contentSecurityPolicy:false})); // อนุญาต CDN ของฟอนต์/ไอคอนในต้นแบบนี้
app.use(express.json({limit:'20kb'}));
app.use(cookieParser());
app.use(express.static(path.join(__dirname,'public')));
const authLimiter = rateLimit({windowMs:15*60*1000,limit:30,standardHeaders:true,legacyHeaders:false,message:{error:'ลองหลายครั้งเกินไป กรุณารอสักครู่แล้วลองใหม่'}});
const COOKIE_NAME = 'aisa_session';
const cookieOptions = {httpOnly:true,secure:NODE_ENV==='production',sameSite:'strict',path:'/',maxAge:7*24*60*60*1000};

function cleanText(value,max=100){return typeof value==='string'?value.trim().slice(0,max):'';}
function validDate(value){return typeof value==='string' && /^\d{4}-\d{2}-\d{2}$/.test(value) && !Number.isNaN(Date.parse(value+'T00:00:00Z'));}
function publicUser(row){return {id:row.id,studentId:row.student_id,firstName:row.first_name,lastName:row.last_name};}
function signToken(user){return jwt.sign({sub:String(user.id)},JWT_SECRET,{expiresIn:'7d',issuer:'aisa'});}
function setSession(res,user){res.cookie(COOKIE_NAME,signToken(user),cookieOptions);}
function requireAuth(req,res,next){
 const token=req.cookies[COOKIE_NAME];
 if(!token)return res.status(401).json({error:'กรุณาเข้าสู่ระบบก่อน'});
 try{
  const payload=jwt.verify(token,JWT_SECRET,{issuer:'aisa'});
  const user=db.prepare('SELECT id,student_id,first_name,last_name FROM users WHERE id=?').get(Number(payload.sub));
  if(!user){res.clearCookie(COOKIE_NAME,{httpOnly:true,secure:NODE_ENV==='production',sameSite:'strict',path:'/'});return res.status(401).json({error:'ไม่พบบัญชีผู้ใช้ กรุณาเข้าสู่ระบบใหม่'});}
  req.user=user;next();
 }catch(e){res.clearCookie(COOKIE_NAME,{httpOnly:true,secure:NODE_ENV==='production',sameSite:'strict',path:'/'});return res.status(401).json({error:'เซสชันหมดอายุ กรุณาเข้าสู่ระบบใหม่'});}
}
function taskFromBody(body){
 const name=cleanText(body.name,100),dueDate=body.dueDate,hours=Number(body.hours);
 if(!name)return {error:'กรุณาระบุชื่องาน'};
 if(!validDate(dueDate))return {error:'กรุณาระบุวันกำหนดส่งให้ถูกต้อง'};
 if(!Number.isFinite(hours)||hours<0.5||hours>100)return {error:'ชั่วโมงที่ใช้ต้องอยู่ระหว่าง 0.5 ถึง 100 ชั่วโมง'};
 return {name,dueDate,hours};
}

// สมัครบัญชีใหม่: รหัสนักศึกษาไม่ซ้ำกัน และ password ถูกแฮชก่อนบันทึก
app.post('/api/auth/register',authLimiter,async(req,res)=>{
 const studentId=cleanText(req.body.studentId,30),firstName=cleanText(req.body.firstName,60),lastName=cleanText(req.body.lastName,60),password=typeof req.body.password==='string'?req.body.password:'';
 if(!/^[A-Za-z0-9-]{4,30}$/.test(studentId))return res.status(400).json({error:'รหัสนักศึกษาต้องมี 4–30 ตัว ใช้ตัวอักษร ตัวเลข หรือขีดกลาง'});
 if(!firstName||!lastName)return res.status(400).json({error:'กรุณากรอกชื่อและนามสกุล'});
 if(password.length<8||password.length>128)return res.status(400).json({error:'รหัสผ่านต้องมี 8–128 ตัวอักษร'});
 try{
  const hash=await bcrypt.hash(password,12);
  const result=db.prepare('INSERT INTO users(student_id,first_name,last_name,password_hash) VALUES(?,?,?,?)').run(studentId,firstName,lastName,hash);
  const user=db.prepare('SELECT id,student_id,first_name,last_name FROM users WHERE id=?').get(result.lastInsertRowid);
  setSession(res,user);return res.status(201).json({user:publicUser(user)});
 }catch(err){if(String(err.code).includes('SQLITE_CONSTRAINT_UNIQUE'))return res.status(409).json({error:'รหัสนักศึกษานี้มีบัญชีแล้ว กรุณาเข้าสู่ระบบ'});console.error(err);return res.status(500).json({error:'สมัครบัญชีไม่สำเร็จ'});}
});
app.post('/api/auth/login',authLimiter,async(req,res)=>{
 const studentId=cleanText(req.body.studentId,30),password=typeof req.body.password==='string'?req.body.password:'';
 const user=db.prepare('SELECT * FROM users WHERE student_id=?').get(studentId);
 const valid=user?await bcrypt.compare(password,user.password_hash):false;
 if(!valid)return res.status(401).json({error:'รหัสนักศึกษาหรือรหัสผ่านไม่ถูกต้อง'});
 setSession(res,user);res.json({user:publicUser(user)});
});
app.get('/api/auth/me',requireAuth,(req,res)=>res.json({user:publicUser(req.user)}));
app.post('/api/auth/logout',(req,res)=>{res.clearCookie(COOKIE_NAME,{httpOnly:true,secure:NODE_ENV==='production',sameSite:'strict',path:'/'});res.json({ok:true});});

// CRUD งาน: ทุกคำสั่งผูกกับ user_id จาก session ป้องกันการอ่าน/แก้ไขงานของบัญชีอื่น
app.get('/api/tasks',requireAuth,(req,res)=>{
 const rows=db.prepare('SELECT id,name,due_date AS dueDate,hours,created_at AS createdAt,updated_at AS updatedAt FROM tasks WHERE user_id=? ORDER BY due_date,id').all(req.user.id);
 res.json({tasks:rows});
});
app.post('/api/tasks',requireAuth,(req,res)=>{
 const task=taskFromBody(req.body);if(task.error)return res.status(400).json({error:task.error});
 const result=db.prepare('INSERT INTO tasks(user_id,name,due_date,hours) VALUES(?,?,?,?)').run(req.user.id,task.name,task.dueDate,task.hours);
 const row=db.prepare('SELECT id,name,due_date AS dueDate,hours,created_at AS createdAt,updated_at AS updatedAt FROM tasks WHERE id=? AND user_id=?').get(result.lastInsertRowid,req.user.id);
 res.status(201).json({task:row});
});
app.put('/api/tasks/:id',requireAuth,(req,res)=>{
 const id=Number(req.params.id);if(!Number.isSafeInteger(id)||id<1)return res.status(400).json({error:'รหัสงานไม่ถูกต้อง'});
 const task=taskFromBody(req.body);if(task.error)return res.status(400).json({error:task.error});
 const result=db.prepare('UPDATE tasks SET name=?,due_date=?,hours=?,updated_at=CURRENT_TIMESTAMP WHERE id=? AND user_id=?').run(task.name,task.dueDate,task.hours,id,req.user.id);
 if(!result.changes)return res.status(404).json({error:'ไม่พบงานนี้ในบัญชีของคุณ'});
 const row=db.prepare('SELECT id,name,due_date AS dueDate,hours,created_at AS createdAt,updated_at AS updatedAt FROM tasks WHERE id=? AND user_id=?').get(id,req.user.id);
 res.json({task:row});
});
app.delete('/api/tasks/:id',requireAuth,(req,res)=>{
 const id=Number(req.params.id);if(!Number.isSafeInteger(id)||id<1)return res.status(400).json({error:'รหัสงานไม่ถูกต้อง'});
 const result=db.prepare('DELETE FROM tasks WHERE id=? AND user_id=?').run(id,req.user.id);
 if(!result.changes)return res.status(404).json({error:'ไม่พบงานนี้ในบัญชีของคุณ'});
 res.json({ok:true});
});
app.get('/api/health',(req,res)=>res.json({ok:true,service:'AI Student Life Assistant API'}));
app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));
app.use((err,req,res,next)=>{console.error(err);res.status(500).json({error:'เกิดข้อผิดพลาดภายในเซิร์ฟเวอร์'});});

app.listen(PORT,()=>console.log(`AI Student Life Assistant เปิดที่ http://localhost:${PORT}`));
