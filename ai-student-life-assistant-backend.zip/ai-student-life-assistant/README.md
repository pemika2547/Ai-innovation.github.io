# AI Student Life Assistant — Backend Edition

เว็บไซต์ต้นแบบภาษาไทยที่มี Backend จริง ใช้ Node.js + Express + SQLite

## สิ่งที่ใช้งานได้
- สมัครบัญชีด้วยรหัสนักศึกษา ชื่อ นามสกุล และรหัสผ่าน
- เข้าสู่ระบบ / ออกจากระบบด้วย cookie แบบ HttpOnly
- รหัสผ่านถูกแฮชด้วย bcrypt ก่อนบันทึกลงฐานข้อมูล
- CRUD งาน: เพิ่ม ดู แก้ไข ลบ
- ข้อมูลแยกตามผู้ใช้ ฝั่ง API ตรวจสอบเจ้าของงานทุกครั้ง
- ข้อมูลอยู่ใน SQLite ที่ `data/student-life.sqlite`
- มี rate limit สำหรับ endpoint สมัคร/เข้าสู่ระบบ
- UI เดิม responsive และเรียก API จาก backend

## ต้องติดตั้ง
- Node.js 20 หรือใหม่กว่า
- npm

## วิธีรันบนเครื่อง
1. แตกไฟล์ ZIP
2. เปิด Terminal/Command Prompt ในโฟลเดอร์โปรเจกต์
3. ติดตั้ง dependencies:

   ```bash
   npm install
   ```

4. ตั้งค่า `JWT_SECRET` เป็นค่าสุ่มยาวอย่างน้อย 32 ตัวอักษร

   macOS / Linux:
   ```bash
   export JWT_SECRET="$(node -e "console.log(require('crypto').randomBytes(48).toString('hex'))")"
   ```

   Windows PowerShell:
   ```powershell
   $env:JWT_SECRET = node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
   ```

5. เริ่มเซิร์ฟเวอร์:

   ```bash
   npm start
   ```

6. เปิด http://localhost:3000

## ทดสอบ
- กด “เข้าสู่ระบบ” แล้วเลือก “สมัครบัญชีใหม่”
- กรอกรหัสนักศึกษา ชื่อ นามสกุล และตั้งรหัสผ่านอย่างน้อย 8 ตัวอักษร
- เพิ่ม/แก้ไข/ลบงาน ข้อมูลจะถูกบันทึกใน SQLite
- ออกจากระบบแล้วเข้าสู่ระบบอีกครั้ง ข้อมูลควรยังอยู่
- ทดสอบ health endpoint ที่ http://localhost:3000/api/health

## API endpoints
- `POST /api/auth/register` — สมัครบัญชี
- `POST /api/auth/login` — เข้าสู่ระบบ
- `GET /api/auth/me` — ดูผู้ใช้ปัจจุบัน
- `POST /api/auth/logout` — ออกจากระบบ
- `GET /api/tasks` — ดูงานของตัวเอง
- `POST /api/tasks` — เพิ่มงาน
- `PUT /api/tasks/:id` — แก้ไขงาน
- `DELETE /api/tasks/:id` — ลบงาน

## ข้อควรทราบก่อนเปิดใช้งานสาธารณะ
- รหัสนักศึกษายังไม่ได้ตรวจสอบกับฐานข้อมูลของมหาวิทยาลัย ดังนั้นการสมัครยืนยันเพียงว่ารหัสนั้นยังไม่ถูกใช้ในระบบนี้ ไม่ได้ยืนยันตัวบุคคลจริง
- ต้อง deploy ผ่าน HTTPS เมื่อใช้ production (cookie จะตั้ง `Secure` เมื่อ `NODE_ENV=production`)
- กำหนด `JWT_SECRET` ที่ปลอดภัยและเก็บเป็น environment secret ห้าม commit ลง Git
- ใช้ persistent disk สำหรับโฟลเดอร์ `data/` เพราะ SQLite เป็นไฟล์ในเครื่องเซิร์ฟเวอร์
- ควรเพิ่มระบบลืมรหัสผ่าน/ยืนยันอีเมล และทดสอบ security เพิ่มก่อนใช้กับข้อมูลจริง
- แผนจัดลำดับในหน้าเว็บเป็นกติกาตัวอย่าง ยังไม่ได้เชื่อมต่อ LLM/API AI จริง
- Font Awesome และ Google Fonts โหลดจาก CDN จึงต้องใช้อินเทอร์เน็ตเพื่อแสดงฟอนต์/ไอคอนภายนอก

## โครงสร้าง
```
ai-student-life-assistant/
├── public/
│   └── index.html
├── data/                 # สร้างอัตโนมัติเมื่อรัน
├── server.js
├── package.json
├── .env.example
└── README.md
```

## Deploy ออนไลน์ด้วย Railway (SQLite ต้องใช้ Volume)
1. อัปโหลดโฟลเดอร์โปรเจกต์นี้เข้า GitHub repository ส่วนตัว
2. สมัคร/เข้าสู่ระบบ Railway แล้วเลือก **New Project → Deploy from GitHub Repo** และเลือก repository
3. เปิด service → **Variables** แล้วเพิ่ม:
   - `JWT_SECRET` = ค่าสุ่มยาวอย่างน้อย 32 ตัวอักษร (ห้ามแชร์ให้ผู้อื่น)
   - `NODE_ENV` = `production`
   - `DATA_DIR` = `/data`
4. เปิด service → **Volumes** แล้วเพิ่ม Volume โดยตั้ง Mount Path เป็น `/data` เพื่อให้ไฟล์ SQLite คงอยู่เมื่อ redeploy/restart
5. รอ deploy เสร็จ แล้วเปิด **Settings → Networking → Generate Domain** เพื่อสร้าง URL สาธารณะ
6. ทดสอบ `https://โดเมนของคุณ/api/health` ควรได้ JSON ที่มี `"ok": true`
7. เปิดโดเมนหลัก สมัครบัญชีทดสอบ เพิ่มงาน แล้ว refresh/restart เพื่อทดสอบว่าข้อมูลยังอยู่

ข้อควรระวัง: การเปิดโดเมนและการใช้ Volume อาจมีค่าใช้จ่ายตามแพ็กเกจและการใช้งานของ Railway โปรดตรวจสอบราคาในบัญชีของคุณก่อนยืนยัน
